//
//  Easypay.h
//  Easypay
//
//  Created by Khawar Shahzad on 05/06/2018.
//  Copyright © 2018 Systems LTD. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Easypay.
FOUNDATION_EXPORT double EasypayVersionNumber;

//! Project version string for Easypay.
FOUNDATION_EXPORT const unsigned char EasypayVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Easypay/PublicHeader.h>


